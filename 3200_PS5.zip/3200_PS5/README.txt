Instructions for running my code:

-Unzip the directory and open it in Matlab
-All of the functions required to run the code are contained within

-Code for #1 is in Problem1.m and SteepestDescent.m
-Code for #2 is in Problem2.m and PowerMethod.m
-The writeup is in the separate PDF file: 3200_PS5.pdf

Thanks!